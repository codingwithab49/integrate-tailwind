import Book from "./Book";

const Books = () => {
    const books = [
        { title: "The Great Gatsby", author: "F. Scott Fitzgerald", onSale: true, featured: false },
        { title: "1984", author: "George Orwell", onSale: false, featured: true },
        { title: "To Kill a Mockingbird", author: "Harper Lee", onSale: true, featured: true },
        { title: "Pride and Prejudice", author: "Jane Austen", onSale: false, featured: false },
        { title: "The Catcher in the Rye", author: "J.D. Salinger", onSale: false, featured: true },
        { title: "Moby-Dick", author: "Herman Melville", onSale: true, featured: false },
    ];

    return (
        <div className="w-full mt-4 flex flex-col items-center">
            {books.map((book, index) => (
                <Book
                    key={index}
                    title={book.title}
                    author={book.author}
                    onSale={book.onSale}
                    featured={book.featured}
                />
            ))}
        </div>
    );

}

export default Books;