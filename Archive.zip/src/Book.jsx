

const Book = ({ title, author, onSale, featured }) => {
    
    const featuredStyles = ""
    const saleStyles = ""
    const redColor = 'red'

    return (
        <div className={`p-4 border-4 rounded mb-4 `} >
            <h2 className="text-lg font-bold">{title}</h2>
            <p className="text-sm text-gray-600">By {author}</p>
            {onSale && <span className={`text-${redColor}-500 font-semibold`}>On Sale</span>}
            {featured && <span className="ml-2 text-yellow-500 font-semibold">Featured</span>}
        </div>
    );
};

export default Book;