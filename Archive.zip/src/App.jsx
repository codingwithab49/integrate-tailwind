import './App.css'
import Books from './Books'

function App() {

  return (
    <div className="min-h-screen bg-gray-100 p-2">
      <div className="w-100 p-4 bg-white shadow rounded-lg text-center">
        <h1 className="">Welcome to Book Shop</h1>
        <p className="mt-4 text-gray-600">Discover your next favorite book with ease!</p>
        <Books />
      </div>
    </div>
  );
}

export default App;
