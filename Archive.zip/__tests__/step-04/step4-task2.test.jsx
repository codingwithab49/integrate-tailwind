import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import Book from '../../src/Book'
import { describe, it, expect } from 'vitest'
import { existsSync } from 'fs'
import path from 'path'
import { createRequire } from 'module'

describe('Book Component and Tailwind Configuration for On Sale', () => {
  it('renders the "On Sale" label with the correct red text class', () => {
    render(<Book title="Test Book" author="Test Author" onSale={true} featured={false} />)
    
    // Find the "On Sale" label.
    const onSaleElement = screen.getByText(/On Sale/i)
    expect(onSaleElement).toBeInTheDocument()
    
    // Verify the label's class includes the fixed class "text-red-500".
    expect(onSaleElement.className).toMatch(/\btext-red-500\b/)
    expect(onSaleElement.className).toMatch(/\bfont-semibold\b/)
  })

  it('ensures tailwind.config.js includes "text-red-500" in its safelist', () => {
    const configPath = path.resolve(process.cwd(), 'tailwind.config.js')
    expect(existsSync(configPath)).toBe(true)
    
    // Load the configuration file.
    const require = createRequire(import.meta.url)
    const configModule = require(configPath)
    const config = configModule.default || configModule

    // Verify the safelist exists and includes "text-red-500".
    expect(config).toHaveProperty('safelist')
    expect(Array.isArray(config.safelist)).toBe(true)
    expect(config.safelist).toContain('text-red-500')
  })
})
