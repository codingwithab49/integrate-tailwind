import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import Book from '../../src/Book'
import { describe, it, expect } from 'vitest'

describe('Book Component Dynamic Styles', () => {
  it('renders without extra styles when not featured and not on sale', () => {
    render(<Book title="Test Book" author="Test Author" onSale={false} featured={false} />)
    const container = screen.getByText("Test Book").parentElement
    // Always-present base classes:
    expect(container).toHaveClass('p-4', 'border-4', 'rounded', 'mb-4')
    // Should NOT include dynamic styles:
    expect(container.className).not.toMatch(/bg-yellow-100/)
    expect(container.className).not.toMatch(/border-yellow-400/)
    expect(container.className).not.toMatch(/bg-red-100/)
    expect(container.className).not.toMatch(/border-red-400/)
  })

  it('applies featured styles when featured is true', () => {
    render(<Book title="Featured Book" author="Test Author" onSale={false} featured={true} />)
    const container = screen.getByText("Featured Book").parentElement
    expect(container.className).toMatch(/bg-yellow-100/)
    expect(container.className).toMatch(/border-yellow-400/)
    // Check that the "Featured" label is rendered
    expect(screen.getByText("Featured")).toBeInTheDocument()
  })

  it('applies onSale styles when onSale is true', () => {
    render(<Book title="Sale Book" author="Test Author" onSale={true} featured={false} />)
    const container = screen.getByText("Sale Book").parentElement
    expect(container.className).toMatch(/bg-red-100/)
    expect(container.className).toMatch(/border-red-400/)
    // Check that the "On Sale" label is rendered
    expect(screen.getByText("On Sale")).toBeInTheDocument()
  })

  it('applies both featured and onSale styles when both props are true', () => {
    render(<Book title="Featured & Sale Book" author="Test Author" onSale={true} featured={true} />)
    const container = screen.getByText("Featured & Sale Book").parentElement
    // expect(container.className).toMatch(/bg-yellow-100/)
    // expect(container.className).toMatch(/border-yellow-400/)
    expect(container.className).toMatch(/bg-red-100/)
    expect(container.className).toMatch(/border-red-400/)
    // Check that both labels are rendered
    expect(screen.getByText("Featured")).toBeInTheDocument()
    expect(screen.getByText("On Sale")).toBeInTheDocument()
  })
})
