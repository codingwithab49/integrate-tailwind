import { describe, it, expect } from 'vitest'
import { existsSync } from 'fs'
import path from 'path'
import { createRequire } from 'module'

describe('Tailwind CSS Configuration', () => {
  it('should have the correct "content" key configuration in tailwind.config.js', () => {
    const configPath = path.resolve(process.cwd(), 'tailwind.config.js')
    expect(existsSync(configPath)).toBe(true)

    // Use createRequire to load a CommonJS module from tailwind.config.js
    const require = createRequire(import.meta.url)
    const config = require(configPath)

    // Check that the config has a "content" key and it is configured as required
    // In case the config is exported as default or directly.
    const configObj = config.default || config
    expect(configObj).toHaveProperty('content')

    // Check that the config has a "content" key
    expect(configObj).toHaveProperty('content')
    expect(Array.isArray(configObj.content)).toBe(true)
    
    // Verify the first element is exactly "./index.html"
    expect(configObj.content[0]).toBe("./index.html")
    
    // Verify the second element follows the required pattern
    const pattern = configObj.content[1]
    // Expect the pattern to start with "./src/**/*.{" and end with "}"
    expect(pattern.startsWith("./src/**/*.{")).toBe(true)
    expect(pattern.endsWith("}")).toBe(true)

    // Extract the file extensions from inside the curly braces
    const match = pattern.match(/\{([^}]+)\}/)
    expect(match).not.toBeNull()
    const extString = match[1]
    const exts = extString.split(',').map(ext => ext.trim())
    
    // The required extensions, order doesn't matter
    const expectedExts = ["js", "jsx", "ts", "tsx"]
    expect(exts.sort()).toEqual(expectedExts.sort())
  })
})
