import { describe, it, expect } from 'vitest'
import { existsSync, readFileSync } from 'fs'
import path from 'path'

describe('Tailwind Directives in src/index.css', () => {
  it('should include the required Tailwind directives', () => {
    const cssFilePath = path.resolve(process.cwd(), 'src/index.css')
    expect(existsSync(cssFilePath)).toBe(true)

    const fileContent = readFileSync(cssFilePath, 'utf8')

    // Check that the file content includes the required Tailwind directives.
    expect(fileContent).toContain('@tailwind base;')
    expect(fileContent).toContain('@tailwind components;')
    expect(fileContent).toContain('@tailwind utilities;')
  })
})
