import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import App from '../../src/App'
import { describe, it, expect } from 'vitest'

describe('Responsive Header in App Component', () => {
  it('should have responsive text sizes on the header', () => {
    render(<App />)
    const header = screen.getByRole('heading', { name: /Welcome to Book Shop/i })
    expect(header).toBeInTheDocument()

    // Check that the header has the required Tailwind classes for responsiveness.
    expect(header).toHaveClass('text-2xl')
    expect(header).toHaveClass('md:text-3xl')
    expect(header).toHaveClass('lg:text-4xl')
  })
})
