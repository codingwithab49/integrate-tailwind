import { render, screen } from '@testing-library/react'
import App from '../../src/App'
import '@testing-library/jest-dom'
import { describe, it, expect } from 'vitest'

describe('App Component', () => {
  it('renders heading with correct text and Tailwind classes', () => {
    render(<App />)
    
    // Find the heading with the text "Welcome to Book Shop"
    const heading = screen.getByRole('heading', { level: 1, name: /Welcome to Book Shop/i })
    expect(heading).toBeInTheDocument()
    
    // Verify that the heading's className includes the required classes.
    const className = heading.className

    expect(className).toMatch(/\btext-2xl\b/)
    expect(className).toMatch(/\bfont-bold\b/)
    expect(className).toMatch(/\btext-gray-800\b/)
  })
})
