import { describe, it, expect } from 'vitest'
import { existsSync } from 'fs'
import path from 'path'

describe('Tailwind CSS Initialization', () => {
  it('should create tailwind.config.js file after executing "npx tailwindcss init -p"', () => {
    const tailwindConfigPath = path.resolve(process.cwd(), 'tailwind.config.js')
    expect(existsSync(tailwindConfigPath)).toBe(true)
  })

  it('should create postcss.config.js file after executing "npx tailwindcss init -p"', () => {
    const postcssConfigPath = path.resolve(process.cwd(), 'postcss.config.js')
    expect(existsSync(postcssConfigPath)).toBe(true)
  })
})
