import { readFileSync } from 'fs'
import { describe, it, expect } from 'vitest'

describe('Tailwind CSS Installation', () => {
  it('should have tailwindcss@3.4.17, postcss, and autoprefixer installed as devDependencies', () => {
    const pkgJson = JSON.parse(readFileSync('package.json', 'utf8'))
    const devDependencies = pkgJson.devDependencies || {}

    // Check if tailwindcss is installed and its version includes "3.4.17"
    expect(devDependencies).toHaveProperty('tailwindcss')
    expect(devDependencies.tailwindcss).toMatch(/3\.4\.17/)

    // Check if postcss and autoprefixer are installed
    expect(devDependencies).toHaveProperty('postcss')
    expect(devDependencies).toHaveProperty('autoprefixer')
  })
})
