import { render, screen } from '@testing-library/react'
import '@testing-library/jest-dom'
import Book from '../../src/Book'
import { describe, it, expect } from 'vitest'

describe('Book Component - Tailwind Merge Utility', () => {
  it('applies only featured styles when only "featured" is true', () => {
    render(<Book title="Featured Only" author="Author" onSale={false} featured={true} />)
    const container = screen.getByText("Featured Only").closest('div')
    // Should include featured styles
    expect(container.className).toMatch(/\bbg-yellow-100\b/)
    expect(container.className).toMatch(/\bborder-yellow-400\b/)
    // Should not include onSale styles
    expect(container.className).not.toMatch(/\bbg-red-100\b/)
    expect(container.className).not.toMatch(/\bborder-red-400\b/)
  })

  it('applies only onSale styles when only "onSale" is true', () => {
    render(<Book title="OnSale Only" author="Author" onSale={true} featured={false} />)
    const container = screen.getByText("OnSale Only").closest('div')
    // Should include onSale styles
    expect(container.className).toMatch(/\bbg-red-100\b/)
    expect(container.className).toMatch(/\bborder-red-400\b/)
    // Should not include featured styles
    expect(container.className).not.toMatch(/\bbg-yellow-100\b/)
    expect(container.className).not.toMatch(/\bborder-yellow-400\b/)
  })

  it('merges styles using tailwind-merge when both "featured" and "onSale" are true', () => {
    render(<Book title="Both Styles" author="Author" onSale={true} featured={true} />)
    const container = screen.getByText("Both Styles").closest('div')
    // With tailwind-merge, conflicting classes are merged such that later ones override.
    // In our implementation, sale styles come second so they should override conflicting featured styles.
    expect(container.className).toMatch(/\bbg-red-100\b/)
    expect(container.className).toMatch(/\bborder-red-400\b/)
    // The merged class should not contain the conflicting featured classes.
    expect(container.className).not.toMatch(/\bbg-yellow-100\b/)
    expect(container.className).not.toMatch(/\bborder-yellow-400\b/)
  })
})
