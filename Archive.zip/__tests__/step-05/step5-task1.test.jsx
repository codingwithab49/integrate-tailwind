// __tests__/tailwindMergeInstallation.test.js
import { describe, it, expect } from 'vitest'
import { existsSync, readFileSync } from 'fs'
import path from 'path'

describe('Tailwind Merge Dependency Installation', () => {
  it('should have tailwind-merge installed as a dependency', () => {
    const packageJsonPath = path.resolve(process.cwd(), 'package.json')
    expect(existsSync(packageJsonPath)).toBe(true)

    const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf8'))
    const dependencies = packageJson.dependencies || {}
    
    expect(dependencies).toHaveProperty('tailwind-merge')
  })
})
