// File: tailwind.config.js 
// modify the content key in the tailwind.config.js file as shown below
module.exports = {
    content: [
        "./index.html",
        "./src/**/*.{js,jsx,ts,tsx}"
    ],
    theme: {
        extend: {},
    },
    plugins: [],
}