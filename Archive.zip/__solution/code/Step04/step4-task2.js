// File: tailwind.config.js
// modify the safelist key as shown below
/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,jsx,ts,tsx}"
    ],
    theme: {
        extend: {},
    },
    plugins: [],
    safelist: [
        'text-red-500',
    ]
}