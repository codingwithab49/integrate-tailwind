// File: src/Book.jsx
// modify the component as shown below
const Book = ({ title, author, onSale, featured }) => {
    
    const featuredStyles = featured ? "bg-yellow-100 border-yellow-400" : ""
    const saleStyles = onSale ? "bg-red-100 border-red-400" : ""
    const redColor = 'red'

    return (
        <div className={`p-4 border-4 rounded mb-4 ${featuredStyles} ${saleStyles}`} >
            <h2 className="text-lg font-bold">{title}</h2>
            <p className="text-sm text-gray-600">By {author}</p>
            {onSale && <span className="text-${redColor}-500 font-semibold">On Sale</span>}
            {featured && <span className="ml-2 text-yellow-500 font-semibold">Featured</span>}
        </div>
    );
};

export default Book;